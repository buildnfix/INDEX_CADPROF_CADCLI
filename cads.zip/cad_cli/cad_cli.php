<!DOCTYPE html>
<html>
<head>
	<title>Build N' Fix | Cadastre-se</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>



	<div class="row mb-5 mt-5">

			<div class="col-sm-4 ml-5">
				<h1 class="display-1 ml-5" id="txtcadastro"> <strong>Construir nunca foi tão fácil. </strong></h1>
				<p class="ml-5"> Participe do Build N' Fix e encontre profissionais qualificados perto de você de forma rápida, segura e fácil. </p>
				<button type="button" class="btn btn-outline-dark ml-5 mt-5">Já sou cadastrado</button>
				<a href="../Index/index.php"><button type="button" class="btn btn-dark ml-5 mt-5">Voltar ao início</button><a>


			</div>

    		<div class="col-sm-4 ml-5">
    			<form id="formulario"  action="#" method="POST" name="formlogin">
						<input type="text" class="form-control" id="nome" name="nome"  placeholder="Nome">
						<input type="text" class="form-control" id="sobrenome" name="sobrenome" placeholder="Sobrenome"></br>
					    <input type="text" class="form-control" id="email" name="email" placeholder="email@exemplo"></br>
					    <input type="text" class="form-control" id="telefone" name="telefone" placeholder="Telefone"></br>
						<input type="text" class="form-control" id="celular" name="celular" placeholder="Celular"><br>
						<!--<select id="estado" class="form-control">
							<option selected>UF</option>
						</select><br>
						<input type="text" class="form-control" id="cep" name="cep" placeholder="CEP"> <br>-->
						<input type="password" class="form-control" id="senha" name="senha" placeholder="Senha">

</br></br>
						<center><button type="submit" class="btn btn-primary col-md-5" name="enviar" value="Cadastrar" id="enviar">Cadastrar</button></center>
					</form>
					
    			</div>
    		</div>
    </div>

	<?php
        include('conexao.php');
                    
            if(isset($_POST['enviar'])){
                $nome=$_POST['nome'];
                $sobrenome=$_POST['sobrenome']; 
                $email=$_POST['email'];
                $senha=$_POST['senha'];
                $senha=sha1($senha);
                $telefone=$_POST['telefone']; 
                $celular=$_POST['celular']; 
                                
                $sql_inserir=('insert into cliente (nome, sobrenome, email, senha, telefone, celular) values ("'.$nome.'","'.$sobrenome.'","'.$email.'","'.$senha.'","'.$telefone.'","'.$celular.'");');
                                
				$inserir=mysqli_query($conexao,$sql_inserir);
				header('location:cad_cli.php');
            } 

    ?>

</body>
</html>