<!DOCTYPE html>
<html>
<head>
	<title>Build N' Fix</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>

<!--- começo do código da nav---->
	<nav class="navbar fixed-top navbar-expand-lg navbar-light" style="background-color: #FFCA28">
		<a class="navbar-brand h2 ml-4" href="index.html">Build N' Fix</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#NavbarSite">
				<span class="navbar-toggler-icon"></span>
		 	</button>

<!---- #navbarsite é o link para o menu responsivo que aparece quando a vizualização é em tamanho tablet/celular --->
	<div class="collapse navbar-collapse" id="NavbarSite">
	  	<div class="container">
	  		<ul class="navbar-nav">
	  			<li class="nav-item">							
	  				<a class="nav-link" href="#"> Home </a>
	  		 	</li>

	  			<li class="nav-item">
	  				<a class="nav-link" href="#"> Profissionais </a>
	  		 	</li>

	  		 	<li class="nav-item">
	  				<a class="nav-link" href="#"> Contratar </a>
	  		 	</li>

	  		 	<li class="nav-item">
	  				<a class="nav-link" href="#"> Termos </a>
	  		 	</li>

	  		 	<li class="nav-item" id="logbt">
	  				<a class="nav-link h5" href="#"> Entrar </a>
				 </li>
				   
				<li class="nav-item">
					<a href="" class="btn btn-dark" data-toggle="modal" data-target="#modalLoginForm">Login</a>
				</li>
					
	  		</ul>
	  	</div>
	  	  </div>
	</nav>
<!------ fim da nav--->	

<!----- Banner do site e descrição ---->
	<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="d-block w-100" src="img/slide1.jpg" alt="First slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 class="display-4">Construir nunca foi tão fácil.</h1>
                        <p><h5>Encontre profissionais qualificados perto de você.</h5></p>
                        
                          <a href="#imgprofissional" class="btn btn-outline-dark" role="button" aria-pressed="true">Sou um profissional</a>
                       	  <a href="#imgcliente" class="btn btn-outline-dark" role="button" aria-pressed="true">Sou um cliente</a>
                   	
                    </div>
             	</div>
            </div>
	</div>
<!--- Fim do Banner --->

  	<center>
  		<br> <br> <br>
  			<h1 class="display-4"> Agilize seu projeto </h1>
  			<p><h5>Conectamos você a profissionais qualificados. Simples assim.</h5>
  	</center>
        <br> <br> <br> <br>

<!------- Colunas com os ícones----->
    <div class="row mb-5">
        <div class="col-sm-4"> 
          	<center>
          		<img src="img/tools.png" class="img-fluid d-block" height="100px" width="100px">
          			<br>Você especifica o serviço que precisa.
          	<center>
        </div>

    	<div class="col-sm-4"> 
        	<center>
          		<img src="img/engineer.png" class="img-fluid d-block" height="100px" width="100px">
          			<br>Nós indicamos os melhores profissionais.
       	 	<center>
    	</div>

    	<div class="col-sm-4"> 
        	<center>
          		<img src="img/chat.png" class="img-fluid d-block" height="100px" width="100px">
          			<br>Vocês combinam o valor e colocam a mão na massa.
          	</center>
   	 	</div>
    </div>

<!------- imagens dos prestadores----->
    <br> <br> <br> <br>
    	<div class="row mb-5">
    		<div class="col-sm-4">
          		<img src="img/prestador.png" id="imgprofissional" class="d-block" height="650px" width="650px">
          	</div>

       		<div class="col-sm-8">
           		 <div id="prestador" style="margin-left: 20%; margin-top: 15%">
            		<div data-spy="scroll" data-target="#navbarVertical" data-offset="0" class="scrollspySite">
            				<p class="text-left display-4" id="profissional">Para Profissionais</p>
            	 			<h5><p class="text-left"> Uma forma prática e segura de encontrar clientes.</p></h5>
            			</div>
            			<br>
            	 			<p class="text-left">O Build N' Fix te ajuda a encontrar projetos especificos</p>
            	 			<p class="text-left"> no seu ramo de atuação em apenas alguns cliques.</p>
           				 <br><br>
<!---botão de cadastro de profissional--->
   <a href="../cad_prof/Cadastro_Profissional.php"><button type="button" class="btn btn-outline-warning mr-5">Cadastre-se como profissional</button></a>

          		
             	</div>
            </div>
        </div>

<!---taki taki roooom baaa--->

		<section id="containertxt" class="text background-gray">
			<div class="container">
					<header>
						<h2>
							A agilidade que você precisa
							<br>
							em um só lugar.
						</h2>
					</header>
				<div class="row">
					<div class="col-md-6">
						<p class="lead">
							Assine o plano que mais se adequa a suas necessidades, encontre clientes, negocie o valor e coloque as mãos na massa.
						</p>

					</div>

					<div class="col-md-6">
						<p class="lead">
							Aproveite os 15 dias de teste grátis e comprove a eficiência da plataforma.

				</div>
		 </section>

<!----------- cards dos planos --------->
    <center>
        <h1 class="display-4"> Nossos Planos</h1>
        	Para todos os profissionais, para todas as necessidades.
    </center>

<!------ div do card loft----->
    <center>
        <div class="row mb-5 mt-5" style="margin-left: 300px;"> 
        	<div class="col-sm-4"> 
        		<div class="card"> 
        			<img class="card-img-top" src="img/house.png">
        				<div class="card-body"> 
        					<h3 class="card-title">Plano Loft</h3>
        					<h5 class="card-subtiltle"> R$20/Mês</h5><br>
        					<h6 class="card-subtiltle">Básico e dinâmico.</h6>
        					<p class="card-text">Upload de até 10 fotos para o portifólio</p><br><br>
        					<button type="button" class="btn btn-outline-warning">Adquira</button><br>
        				</div>
        			</div>
       			</div>

<!------ div do card master------>
    		<div class="col-sm-4"> 
        		<div class="card"> 
        			<img class="card-img-top" src="img/duplex.png">
        			<div class="card-body"> 
        				<h3 class="card-title">Plano Master</h3>
        				<h5 class="card-subtiltle"> R$30/Mês</h5> <br>
        				<h6 class="card-subtiltle">Completo e inovador.</h6>
        				<p class="card-text"> Upload de até 50 fotos para o portifólio </p>
        				<p class="card-text"> Destaque no feed </p>
        				<button type="button" class="btn btn-outline-warning">Adquira</button>
        			</div>
        		</div>
        	</div>
        </div>
    </center>
<!----------- fim das divs de card-------------->



<!---------div do contratante------------------->
    <div class="row mb-5 ml-5">
    	<div class="col-sm-4 mt-5 ml-5">
    		
    			<div data-spy="scroll" data-target="#navbarVertical" data-offset="0" class="scrollspySite">
    	 			<h1 class="text-right display-4" id="cliente"> Para quem quer construir. </h1>
    	 			<h5 class="text-right"> Um jeito rápido de encontrar os melhores profissionais.</h5>
    	 			<br><br><br><br>
    	 			<p class="text-right"> Encontre prestadores de serviço de forma prática com base nas demandas do seu projeto de forma rápida e gratuita.</p>
    	 			<br><br><br>
    	 			<a href="../cad_cli/cad_cli.php"><button type="button" class="btn btn-outline-warning" id="btcli">Cadastre-se como Cliente</button>
    	 		</div>
    
    	</div>

    	<div class="col-sm-4 mr-5">
    		<img src="img/contratante.png" id="imgcliente" width="500px" height="500px" style="margin-left: 250px">
        </div>	
    </div>

  <br><br><br>

  
<!----------fim da div de contratante------>

<!-------início do fooooooooooter---------->
  <center
    <div id="footer">
      <hr color="#c2c2c2">
      	<h1 class="lead text-white"> <font size="6"> Build N' Fix </font></h1>
      	<h6 class="lead text-muted">Construir nunca foi tão fácil.</h6>

      	<ul class="site-links list-inline">
      		<li class="list-inline-item">
      			<a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Quem somos </a>
      		</li>

      		<li class="list-inline-item">
      			<a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Contato </a>
      		</li>

      		<li class="list-inline-item">
      			<a href="#" class="lead" style="text-decoration:none; color:#ffca28"> Suporte </a>
      		</li>

      	</ul>

      		<form id="formularionews" action=#>

      			<div class="form-group"> 
      				<input type="text" name="contato" id="contato" placeholder="Assine nossa Newsletter">
      				<button type="button" class="btn btn-outline-light" id="btnews">Inscrever</button>
      			</div>
      		</form> <br>

      	<h5 class="lead text-white-50"> Etec de Santa Isabel, Santa Isabel-SP</h4> <br>
      	<h5 class="lead text-white">buildnfix@email.com</h4> <br>
      		<div id="copyright">
      			<p class="lead text-muted"> <br> @2019 Build 'N Fix. Todos os direitos reservados. </p>

      		</div>

    </div>
  </center>
     	</body>
</html>